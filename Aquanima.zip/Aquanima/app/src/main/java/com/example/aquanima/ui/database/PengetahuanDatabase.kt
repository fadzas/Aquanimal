package com.example.aquanima.ui.database

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.aquanima.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONException
import java.io.BufferedReader

@Database(entities = [PengetahuanItem::class], version = 1)
abstract class PengetahuanDatabase : RoomDatabase() {
    abstract fun dao(): PengetahuanDao

    companion object{
        @Volatile
        private var instance : PengetahuanDatabase? = null

        fun getInstance(context: Context): PengetahuanDatabase?{
            if(instance == null){
                synchronized(PengetahuanDatabase::class.java){
                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        PengetahuanDatabase::class.java,
                        "pengetahuan"
                    )
                        .addCallback(object : RoomDatabase.Callback(){
                            override fun onCreate(db: SupportSQLiteDatabase) {
                                super.onCreate(db)
                                CoroutineScope(Dispatchers.IO).launch {
                                    fillWithStartingPengetahuan(context, getInstance(context)!!.dao())
                                }
                            }
                        })
                        .build()
                }
            }
            return instance
        }

        private fun loadJSONArray(context: Context): JSONArray?{
            val inputStream = context.resources.openRawResource(R.raw.pengetahuan)
            BufferedReader(inputStream.reader()).use {
                return JSONArray(it.readText())
            }
        }
        private fun fillWithStartingPengetahuan(context: Context, dao: PengetahuanDao){
            val pengetahuan = loadJSONArray(context)
            try{
                if (pengetahuan != null){
                    for (i in 0 until pengetahuan.length()){
                        val item  = pengetahuan.getJSONObject(i)
                        val imgUrl = item.getString("imgUrl")
                        val title = item.getString("title")
                        val desc = item.getString("description")

                        val pengetahuanEntity = PengetahuanItem(
                            imgUrl,title,desc
                        )
                        dao.insert(pengetahuanEntity)
                    }
                }
            }
            catch (e: JSONException) {
                Log.d("ada Error :", "fillWithStartingNotes: $e")
            }
        }
    }
}