package com.example.aquanima.ui.database

import android.app.Application
import androidx.lifecycle.LiveData
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class PengetahuanRepository(application: Application) {
    private val mPengetahuanDao : PengetahuanDao
    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()
    init {
        val db = PengetahuanDatabase.getInstance(application)
        mPengetahuanDao = db!!.dao()
    }
    fun getSearchData(search : String): LiveData<List<PengetahuanItem>> = mPengetahuanDao.searchByTitle(search)
    fun getAllPengetahuan(): LiveData<List<PengetahuanItem>> = mPengetahuanDao.getAllData()
    fun getDetailPengetahuan(id : Int): LiveData<PengetahuanItem> = mPengetahuanDao.getDetailData(id)

    fun insert(pengetahuan : PengetahuanItem) {
        executorService.execute { mPengetahuanDao.insert(pengetahuan) }
    }
    fun update(pengetahuan : PengetahuanItem){
        executorService.execute { mPengetahuanDao.update(pengetahuan) }
    }
    fun delete(pengetahuan : PengetahuanItem){
        executorService.execute { mPengetahuanDao.delete(pengetahuan) }
    }
}