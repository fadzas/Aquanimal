package com.example.aquanima.ui.database

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class PengertahuanDb (
    val imgUrl : String,
    val title : String,
    val desc : String
):Parcelable
