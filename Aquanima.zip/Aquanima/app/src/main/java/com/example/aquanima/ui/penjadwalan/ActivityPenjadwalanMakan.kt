package com.example.aquanima.ui.penjadwalan

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import com.example.aquanima.AlarmReceiver
import com.example.aquanima.MainActivity
import com.example.aquanima.R
import com.example.aquanima.databinding.ActivityPenjadwalanMakanBinding
import java.text.SimpleDateFormat
import java.util.*

class ActivityPenjadwalanMakan : AppCompatActivity(), View.OnClickListener, TimePickerFragment.DialogTimeListener {
        private var binding: ActivityPenjadwalanMakanBinding? = null
        private lateinit var alarmReceiver: AlarmReceiver


    companion object {
            private const val TIME_PICKER_REPEAT_TAG = "TimePickerRepeat"
        }

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityPenjadwalanMakanBinding.inflate(layoutInflater)
            setContentView(binding?.root)

            // Listener repeating alarm
            binding?.btnRepeatingTime?.setOnClickListener(this)
            binding?.btnSetRepeatingAlarm?.setOnClickListener(this)
            binding?.btnCancelRepeatingAlarm?.setOnClickListener(this)

            alarmReceiver = AlarmReceiver()
        }

        override fun onClick(v: View) {
            when (v.id) {
                R.id.btn_repeating_time -> {
                    val timePickerFragmentRepeat = TimePickerFragment()
                    timePickerFragmentRepeat.show(supportFragmentManager, TIME_PICKER_REPEAT_TAG)
                }
                R.id.btn_set_repeating_alarm -> {
                    val repeatTime = binding?.tvRepeatingTime?.text.toString()
                    val repeatMessage = binding?.edtRepeatingMessage?.text.toString()
                    Log.d(repeatTime, "ada isinya $repeatTime")
                    alarmReceiver.setRepeatingAlarm(this, AlarmReceiver.TYPE_REPEATING,
                        repeatTime, repeatMessage)
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                }
                R.id.btn_cancel_repeating_alarm -> {
                    alarmReceiver.cancelAlarm(this,AlarmReceiver.TYPE_REPEATING)
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                }
            }
        }

        override fun onDialogTimeSet(tag: String?, hourOfDay: Int, minute: Int) {

            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
            calendar.set(Calendar.MINUTE, minute)

            val dateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

            when (tag) {
                TIME_PICKER_REPEAT_TAG -> binding?.tvRepeatingTime?.text = dateFormat.format(calendar.time)
                else -> {
                }
            }
        }

        override fun onDestroy() {
            super.onDestroy()

            binding = null
        }
    }