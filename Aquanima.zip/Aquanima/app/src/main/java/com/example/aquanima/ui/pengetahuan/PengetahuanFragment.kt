package com.example.aquanima.ui.pengetahuan

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.aquanima.databinding.FragmentPengetahuanBinding
import com.example.aquanima.ui.database.PengetahuanItem
import com.example.aquanima.ui.adapter.ListPengetahuanAdapter

class PengetahuanFragment : Fragment() {

    private var _binding: FragmentPengetahuanBinding? = null
    private val binding get() = _binding!!
    private lateinit var rvPengetahuan : RecyclerView
    private lateinit var pengetahuanSearch : SearchView
    private val pengetahuanViewModel : PengetahuanViewModel by viewModels {
        ViewModelFactory.getInstance(requireActivity().application)
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentPengetahuanBinding.inflate(inflater, container, false)
        val root: View = binding.root
        rvPengetahuan = binding.rvPengetahuan
        rvPengetahuan.setHasFixedSize(true)
        pengetahuanViewModel.getAllData().observe(requireActivity()){
            showRecyclerList(it)
        }

        pengetahuanSearch = binding.searchView
        pengetahuanSearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
               if (query != null) {
                   searchData(query.toString())
               }else{
                   pengetahuanViewModel.getAllData().observe(requireActivity()){
                       showRecyclerList(it)
                   }
               }

                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText != null) {
                    searchData(newText.toString())
                }else{
                    pengetahuanViewModel.getAllData().observe(requireActivity()){
                        showRecyclerList(it)
                    }
                }
                return false
            }
        })

        return root

    }

    private fun showRecyclerList(list: List<PengetahuanItem>) {
        rvPengetahuan.layoutManager = LinearLayoutManager(requireContext())
        val listPengetahuanAdapter = ListPengetahuanAdapter(list)
        rvPengetahuan.adapter = listPengetahuanAdapter

        listPengetahuanAdapter.setItemClickCallback(object : ListPengetahuanAdapter.OnItemClickCallback{
            override fun onItemClicked(data: PengetahuanItem) {
                val intentToDetail = Intent(requireActivity(),ActivityDetailPengetahuan::class.java)
                intentToDetail.putExtra(ActivityDetailPengetahuan.EXTRA_DETAIL_OBJECT,data.id.toInt())
                startActivity(intentToDetail)
            }
        })

    }
    fun searchData(search: String){
        pengetahuanViewModel.getSearchData(search).observe(requireActivity()){
            showRecyclerList(it)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}