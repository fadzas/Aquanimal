package com.example.aquanima.ui.analisis

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.aquanima.R
import com.example.aquanima.databinding.FragmentAnalisisBinding

class AnalisisFragment : Fragment() {

    private var _binding: FragmentAnalisisBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAnalisisBinding.inflate(inflater, container, false)
        val root: View = binding.root

        binding.btnSetHasil.setOnClickListener{
            when (it.id) {
                R.id.btn_set_hasil -> {

                    var ph = binding.edtPh.text.toString()
                    if(ph.isEmpty())
                        ph = "-99.99"
                    val intPh = ph.toDouble()

                    if(intPh in 6.5..6.8){
                        val text = binding.tvHasilPh
                        text.text = "PH Dalam Tingkat Yang Baik"
                        text.setTextColor(Color.parseColor("#36AE7C"))
                        val img = binding.imgAcc
                        img.visibility = View.VISIBLE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE

                    }else if(intPh == -99.99) {
                        val text = binding.tvHasilPh
                        text.text = "Input data terlebih dahulu"
                        text.setTextColor(Color.parseColor("#797979"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE

                    }else if(intPh in 6.1..6.5){
                        val text = binding.tvHasilPh
                        text.text = "Kadar PH Kurang tinggi"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE

                    }else if(intPh in 6.8..7.2){
                        val text = binding.tvHasilPh
                        text.text = "Kadar PH Terlalu Tinggi"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE

                    }else if(intPh < 6.1){
                        val text = binding.tvHasilPh
                        text.text = "Kadar PH Sangat Rendah!"
                        text.setTextColor(Color.parseColor("#F92323"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.VISIBLE

                    }else if(intPh > 7.3){
                        val text = binding.tvHasilPh
                        text.text = "Kadar PH Sangat Tinggi!"
                        text.setTextColor(Color.parseColor("#F92323"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.VISIBLE
                    }else{
                        val text = binding.tvHasilPh
                        text.text = "-"
                        text.setTextColor(Color.parseColor("#FFFFFF"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE
                    }

                    // Perhitungan KH
                    var kh = binding.edtKh.text.toString()
                    if(kh.isEmpty())
                        kh = "-99.99"
                    val intKh = kh.toDouble()
                    if(intKh in 4.0..8.0){
                        val text = binding.tvHasilKh
                        text.text = "KH Dalam Tingkat Yang Baik"
                        text.setTextColor(Color.parseColor("#36AE7C"))
                        val img = binding.imgAcc2
                        img.visibility = View.VISIBLE
                        val imgWarn = binding.imgWarn2
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger2
                        imgDanger.visibility = View.GONE

                    }else if(intKh == -99.99) {
                        val text = binding.tvHasilKh
                        text.text = "Input data terlebih dahulu"
                        text.setTextColor(Color.parseColor("#797979"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE

                    }else if(intKh in 0.0..4.0){
                        val text = binding.tvHasilKh
                        text.text = "Kadar KH Kurang tinggi"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc2
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn2
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger2
                        imgDanger.visibility = View.GONE

                    }else if(intKh in 8.0..12.0){
                        val text = binding.tvHasilKh
                        text.text = "Kadar KH Terlalu Tinggi"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc2
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn2
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger2
                        imgDanger.visibility = View.GONE

                    }else if(intKh > 12.0){
                        val text = binding.tvHasilKh
                        text.text = "Kadar KH Sangat Tinggi!"
                        text.setTextColor(Color.parseColor("#F92323"))
                        val img = binding.imgAcc2
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn2
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger2
                        imgDanger.visibility = View.VISIBLE
                    }else{
                        val text = binding.tvHasilKh
                        text.text = "-"
                        text.setTextColor(Color.parseColor("#FFFFFF"))
                        val img = binding.imgAcc2
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn2
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger2
                        imgDanger.visibility = View.GONE
                    }

                    // Perhitungan GH
                    var gh = binding.edtGh.text.toString()
                    if(gh.isEmpty())
                        gh = "-99.99"
                    val intGh = gh.toDouble()
                    if(intGh in 4.0..8.0){
                        val text = binding.tvHasilGh
                        text.text = "GH Dalam Tingkat Yang Baik"
                        text.setTextColor(Color.parseColor("#36AE7C"))
                        val img = binding.imgAcc3
                        img.visibility = View.VISIBLE
                        val imgWarn = binding.imgWarn3
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger3
                        imgDanger.visibility = View.GONE

                    }else if(intGh == -99.99) {
                        val text = binding.tvHasilGh
                        text.text = "Input data terlebih dahulu"
                        text.setTextColor(Color.parseColor("#797979"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE

                    }else if(intGh in 0.0..4.0){
                        val text = binding.tvHasilGh
                        text.text = "Kadar GH Kurang tinggi"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc3
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn3
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger3
                        imgDanger.visibility = View.GONE

                    }else if(intGh in 8.0..14.0){
                        val text = binding.tvHasilGh
                        text.text = "Kadar GH Mulai Tinggi"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc3
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn3
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger3
                        imgDanger.visibility = View.GONE

                    }else if(intGh > 14.0){
                        val text = binding.tvHasilGh
                        text.text = "Kadar GH Sangat Tinggi!"
                        text.setTextColor(Color.parseColor("#F92323"))
                        val img = binding.imgAcc3
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn3
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger3
                        imgDanger.visibility = View.VISIBLE
                    }else{
                        val text = binding.tvHasilGh
                        text.text = "-"
                        text.setTextColor(Color.parseColor("#FFFFFF"))
                        val img = binding.imgAcc3
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn3
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger3
                        imgDanger.visibility = View.GONE
                    }

                    // Perhitungan Suhu
                    var th = binding.edtTh.text.toString()
                    if(th.isEmpty())
                        th = "-99.99"
                    val intTh = th.toDouble()
                    if(intTh in 24.0..28.0){
                        val text = binding.tvHasilTh
                        text.text = "Suhu Dalam Tingkat Yang Baik"
                        text.setTextColor(Color.parseColor("#36AE7C"))
                        val img = binding.imgAcc4
                        img.visibility = View.VISIBLE
                        val imgWarn = binding.imgWarn4
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger4
                        imgDanger.visibility = View.GONE

                    }else if(intTh == -99.99) {
                        val text = binding.tvHasilTh
                        text.text = "Input data terlebih dahulu"
                        text.setTextColor(Color.parseColor("#797979"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE

                    }else if(intTh in 18.0..24.0){
                        val text = binding.tvHasilTh
                        text.text = "Suhu Air Mulai Dingin"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc4
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn4
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger4
                        imgDanger.visibility = View.GONE

                    }else if(intTh in 28.0..32.0){
                        val text = binding.tvHasilTh
                        text.text = "Suhu Air Mulai Panas"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc4
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn4
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger4
                        imgDanger.visibility = View.GONE

                    }else if(intTh < 18.0){
                        val text = binding.tvHasilTh
                        text.text = "Suhu Air Sangat Dingin!"
                        text.setTextColor(Color.parseColor("#F92323"))
                        val img = binding.imgAcc4
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn4
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger4
                        imgDanger.visibility = View.VISIBLE

                    }else if(intTh > 32.0){
                        val text = binding.tvHasilTh
                        text.text = "Suhu Air sangat Panas!"
                        text.setTextColor(Color.parseColor("#F92323"))
                        val img = binding.imgAcc4
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn4
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger4
                        imgDanger.visibility = View.VISIBLE
                    }else{
                        val text = binding.tvHasilTh
                        text.text = "-"
                        text.setTextColor(Color.parseColor("#FFFFFF"))
                        val img = binding.imgAcc4
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn4
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger4
                        imgDanger.visibility = View.GONE
                    }

                    // Perhitungan Amonia
                    var am = binding.edtAm.text.toString()
                    if(am.isEmpty())
                        am = "-99.99"
                    val intAm = am.toDouble()
                    if(intAm in 0.0..0.05){
                        val text = binding.tvHasilAm
                        text.text = "Amonia Sangat Rendah"
                        text.setTextColor(Color.parseColor("#36AE7C"))
                        val img = binding.imgAcc5
                        img.visibility = View.VISIBLE
                        val imgWarn = binding.imgWarn5
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger5
                        imgDanger.visibility = View.GONE

                    }else if(intAm == -99.99) {
                        val text = binding.tvHasilAm
                        text.text = "Input data terlebih dahulu"
                        text.setTextColor(Color.parseColor("#797979"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE

                    }else if(intAm in 0.05..0.2) {
                        val text = binding.tvHasilAm
                        text.text = "Kadar Amonia Meningkat"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc5
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn5
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger5
                        imgDanger.visibility = View.GONE

                    }else if(intAm > 0.2){
                        val text = binding.tvHasilAm
                        text.text = "Kadar Amonia Sangat Tinggi"
                        text.setTextColor(Color.parseColor("#F92323"))
                        val img = binding.imgAcc5
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn5
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger5
                        imgDanger.visibility = View.VISIBLE

                    }else{
                        val text = binding.tvHasilAm
                        text.text = "-"
                        text.setTextColor(Color.parseColor("#FFFFFF"))
                        val img = binding.imgAcc5
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn5
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger5
                        imgDanger.visibility = View.GONE
                    }

                    // Perhitungan Nitrate
                    var nat = binding.edtNat.text.toString()
                    if(nat.isEmpty())
                        nat = "-99.99"
                    val intNat = nat.toDouble()
                    if(intNat in 0.0..50.0){
                        val text = binding.tvHasilNat
                        text.text = "Kadar Nitrate Sangat Rendah"
                        text.setTextColor(Color.parseColor("#36AE7C"))
                        val img = binding.imgAcc6
                        img.visibility = View.VISIBLE
                        val imgWarn = binding.imgWarn6
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger6
                        imgDanger.visibility = View.GONE

                    }else if(intNat == -99.99) {
                        val text = binding.tvHasilNat
                        text.text = "Input data terlebih dahulu"
                        text.setTextColor(Color.parseColor("#797979"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE

                    }else if(intNat in 50.0..100.0){
                        val text = binding.tvHasilNat
                        text.text = "Kadar Nitrate Meningkat"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc6
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn6
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger6
                        imgDanger.visibility = View.GONE

                    }else if(intNat > 100.0){
                        val text = binding.tvHasilNat
                        text.text = "Kadar Nitrate Sangat Tinggi"
                        text.setTextColor(Color.parseColor("#F92323"))
                        val img = binding.imgAcc6
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn6
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger6
                        imgDanger.visibility = View.VISIBLE

                    }else{
                        val text = binding.tvHasilNat
                        text.text = "-"
                        text.setTextColor(Color.parseColor("#FFFFFF"))
                        val img = binding.imgAcc6
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn6
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger6
                        imgDanger.visibility = View.GONE
                    }

                    // Perhitungan Nitrite
                    var nit = binding.edtNit.text.toString()
                    if(nit.isEmpty())
                        nit = "-99.99"
                    val intNit = nit.toDouble()
                    if(intNit in 0.0..0.2){
                        val text = binding.tvHasilNit
                        text.text = "Kadar Nitrite Sangat Rendah"
                        text.setTextColor(Color.parseColor("#36AE7C"))
                        val img = binding.imgAcc7
                        img.visibility = View.VISIBLE
                        val imgWarn = binding.imgWarn7
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger7
                        imgDanger.visibility = View.GONE

                    }else if(intNit == -99.99) {
                        val text = binding.tvHasilNit
                        text.text = "Input data terlebih dahulu"
                        text.setTextColor(Color.parseColor("#797979"))
                        val img = binding.imgAcc
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger
                        imgDanger.visibility = View.GONE

                    }else if(intNit in 0.2..0.5){
                        val text = binding.tvHasilNit
                        text.text = "Kadar Nitrite Meningkat"
                        text.setTextColor(Color.parseColor("#F9D923"))
                        val img = binding.imgAcc7
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn7
                        imgWarn.visibility = View.VISIBLE
                        val imgDanger = binding.imgDanger7
                        imgDanger.visibility = View.GONE

                    }else if(intNit > 0.5){
                        val text = binding.tvHasilNit
                        text.text = "Kadar Nitrite Sangat Tinggi"
                        text.setTextColor(Color.parseColor("#F92323"))
                        val img = binding.imgAcc7
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn7
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger7
                        imgDanger.visibility = View.VISIBLE

                    }else{
                        val text = binding.tvHasilNit
                        text.text = "-"
                        text.setTextColor(Color.parseColor("#FFFFFF"))
                        val img = binding.imgAcc7
                        img.visibility = View.GONE
                        val imgWarn = binding.imgWarn7
                        imgWarn.visibility = View.GONE
                        val imgDanger = binding.imgDanger7
                        imgDanger.visibility = View.GONE
                    }

                }
            }
        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}