package com.example.aquanima.ui.pengetahuan

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.aquanima.ui.database.PengetahuanItem
import com.example.aquanima.ui.database.PengetahuanRepository

class PengetahuanViewModel (application: Application) : ViewModel() {
    private val mPengetahuanRepository: PengetahuanRepository = PengetahuanRepository(application)

    val getSearchData :(search : String) -> LiveData<List<PengetahuanItem>> = { search ->
        mPengetahuanRepository.getSearchData(search)
    }
    val getAllData :() -> LiveData<List<PengetahuanItem>> = {
        mPengetahuanRepository.getAllPengetahuan()
    }
    val getDetailData: (id : Int) -> LiveData<PengetahuanItem> = { id ->
        mPengetahuanRepository.getDetailPengetahuan(id)
    }

    fun insert(pengetahuan: PengetahuanItem) {
        mPengetahuanRepository.insert(pengetahuan)
    }
    fun update(pengetahuan: PengetahuanItem) {
        mPengetahuanRepository.update(pengetahuan)
    }
    fun delete(pengetahuan: PengetahuanItem) {
        mPengetahuanRepository.delete(pengetahuan)
    }
}