package com.example.aquanima.ui.database

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface PengetahuanDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(pengetahuanItem: PengetahuanItem)

    @Update
    fun update(pengetahuanItem: PengetahuanItem)

    @Delete
    fun delete(pengetahuanItem: PengetahuanItem)

    @Query("SELECT * from pengetahuan_table ORDER BY id ASC")
    fun getAllData(): LiveData<List<PengetahuanItem>>

    @Query("SELECT * from pengetahuan_table WHERE id = :id")
    fun getDetailData(id : Int): LiveData<PengetahuanItem>

    @Query("SELECT * from pengetahuan_table WHERE title LIKE '%' || :search || '%'")
    fun searchByTitle(search: String): LiveData<List<PengetahuanItem>>
}
