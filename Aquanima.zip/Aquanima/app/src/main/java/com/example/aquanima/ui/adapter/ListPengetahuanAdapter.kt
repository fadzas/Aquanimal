package com.example.aquanima.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.aquanima.R
import com.example.aquanima.ui.database.PengetahuanItem

class ListPengetahuanAdapter (private val listPengetahuan: List<PengetahuanItem>):RecyclerView.Adapter<ListPengetahuanAdapter.ListViewHolder>() {

    private lateinit var onItemClickCallback : OnItemClickCallback
    interface OnItemClickCallback{
        fun onItemClicked(data: PengetahuanItem)
    }
    fun setItemClickCallback(onItemClickCallback: OnItemClickCallback){
        this.onItemClickCallback = onItemClickCallback
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.pengetahuan_card, parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val (photo, name, description) = listPengetahuan[position]
        Glide.with(holder.itemView)
            .load(photo)
            .placeholder(R.drawable.ic_launcher_background)
            .centerCrop()
            .into(holder.imgPhoto)
        holder.tvName.text = name
        holder.tvDescription.text = description

        holder.itemView.setOnClickListener {
            onItemClickCallback.onItemClicked(listPengetahuan[position])
        }
    }

    override fun getItemCount(): Int = listPengetahuan.size

    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgPhoto: ImageView = itemView.findViewById(R.id.imgPengetahuan)
        val tvName: TextView = itemView.findViewById(R.id.title)
        val tvDescription: TextView = itemView.findViewById(R.id.desc)
    }
}