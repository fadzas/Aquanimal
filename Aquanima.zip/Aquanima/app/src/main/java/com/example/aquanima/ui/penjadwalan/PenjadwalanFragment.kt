package com.example.aquanima.ui.penjadwalan

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.example.aquanima.AlarmReceiver
import com.example.aquanima.databinding.FragmentPenjadwalanBinding

class PenjadwalanFragment : Fragment() {
    private var _binding: FragmentPenjadwalanBinding? = null
    private val binding get() = _binding!!
    private lateinit var alarmReceiver: AlarmReceiver
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentPenjadwalanBinding.inflate(inflater, container, false)
        val root: View = binding.root

        return root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val btnOneTimeAlarm: Button = binding.btnSetOnceAlarm
        val btnRepeaterAlarm: Button = binding.btnSetRepeatingAlarm
        val btnDeleteAlarm: Button = binding.btnDeleteRepeatingAlarm
        alarmReceiver = AlarmReceiver()

        btnDeleteAlarm.setOnClickListener(){
            alarmReceiver.cancelAlarm(requireContext(),AlarmReceiver.TYPE_REPEATING)
        }
        btnOneTimeAlarm.setOnClickListener{
            val intent = Intent(activity, ActivityPenjadwalan::class.java)
            startActivity(intent)
        }
        btnRepeaterAlarm.setOnClickListener {
            val intent2 = Intent(activity, ActivityPenjadwalanMakan::class.java)
            startActivity(intent2)
        }
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}