package com.example.aquanima.ui.pengetahuan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import com.bumptech.glide.Glide
import com.example.aquanima.databinding.ActivityDetailPengetahuanBinding

class ActivityDetailPengetahuan : AppCompatActivity() {
    private lateinit var binding: ActivityDetailPengetahuanBinding
    private val detailViewModel: PengetahuanViewModel by viewModels {
        ViewModelFactory.getInstance(application)
    }
    companion object {
        const val EXTRA_DETAIL_OBJECT = "object"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailPengetahuanBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        val pengetahuanDetailId = intent.getIntExtra(EXTRA_DETAIL_OBJECT, 0)
        Log.d("ADA IDNYA:", pengetahuanDetailId.toString())
        setupData(pengetahuanDetailId)
    }
    private fun setupData(pengetahuanDetailId: Int){
        detailViewModel.getDetailData(pengetahuanDetailId).observe(this){
            binding.apply {
                Glide.with(this@ActivityDetailPengetahuan)
                    .load(it.imgUrl)
                    .placeholder(androidx.appcompat.R.drawable.abc_ic_clear_material)
                    .centerCrop()
                    .into(binding.imgObject)

                tvTitle.text = it.title
                tvDesc.text = it.desc
            }
        }
    }
}